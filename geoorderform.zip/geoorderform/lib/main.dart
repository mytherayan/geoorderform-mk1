import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'order_form.dart'; // Import the order form
import 'LoginPage.dart'; // Import the order form
import 'presentation.dart'; // Import the order form



import 'package:mysql1/mysql1.dart';
import 'package:mysql1/mysql1.dart';

import 'package:mysql1/mysql1.dart';

/*
class DatabaseHelper {
  // Database connection parameters
  final ConnectionSettings settings = ConnectionSettings(
    host: 'sql204.infinityfree.com',
    port: 3306,
    user: 'if0_37218443',
    password: 'oeeT1eqSHE',
    db: 'if0_37218443_flutterdemokice',
  );

  // Method to establish a connection
  Future<MySqlConnection> _connect() async {
    try {
      var conn = await MySqlConnection.connect(settings);
      print('Connected to the database!');
      return conn;
    } catch (e) {
      print('Connection error: $e');
      rethrow;
    }
  }

  // Method to execute a query
  Future<List<Map<String, dynamic>>> query(String sql) async {
    var conn = await _connect();
    List<Map<String, dynamic>> results = [];

    try {
      var queryResults = await conn.query(sql);
      for (var row in queryResults) {
        results.add(row.fields);
      }
    } catch (e) {
      print('Query error: $e');
    } finally {
      await conn.close();
    }

    return results;
  }

  // Method for insert, update, delete
  Future<int?> execute(String sql) async {
    var conn = await _connect();
    int? affectedRows = 0;

    try {
      var result = await conn.query(sql);
      affectedRows = result.affectedRows;
    } catch (e) {
      print('Execution error: $e');
    } finally {
      await conn.close();
    }

    return affectedRows;
  }
}


class DatabaseExample extends StatefulWidget {
  @override
  _DatabaseExampleState createState() => _DatabaseExampleState();
}

class _DatabaseExampleState extends State<DatabaseExample> {
  final DatabaseHelper dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> _data = [];

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    String sql = 'SELECT * FROM `departments`'; // Replace with your table name
    var results = await dbHelper.query(sql);
    setState(() {
      _data = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: _data.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(_data[index]['id']), // Replace with your column name
        );
      },
    );
  }
}
*/



void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Order Dashboard',

      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Dashboard extends StatefulWidget {

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {

  int _selectedIndex = 0;

  static List<Widget> _screens = <Widget>[

    HomePage(),
    // DatabaseExample(),
    // HomeScreenLoop(),

    PlaceholderWidget('Receipt'),
    PlaceholderWidget('Account'),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: 'Orders'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt), label: 'Invoice'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long), label: 'Receipt'),
          BottomNavigationBarItem(icon: Icon(Icons.account_circle), label: 'Account'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.red,
        unselectedItemColor: Colors.black,
        showUnselectedLabels: true,

        onTap: _onItemTapped,
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Drawer(),
              Icon(Icons.menu),
              Text('Geo'),
              GestureDetector(
                  onTap: (){
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => OrderFormScreen()),
                    );

                  },
                  child: Icon(Icons.add_chart))
            ],
          ),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 28.0),
              child: Text('Hi $UniversalAgentName',style: TextStyle(fontSize: 22),),
            ),
            Expanded(child: Center(child: Text('Order List'))),
          ],
        ))
    ;
  }
}


class PlaceholderWidget extends StatelessWidget {
  final String title;

  PlaceholderWidget(this.title);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(title, style: TextStyle(fontSize: 24)),
    );
  }
}
