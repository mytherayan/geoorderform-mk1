import 'dart:io';

import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:flutter_dropdown_search/flutter_dropdown_search.dart';
import 'dart:convert';
import 'dart:io';
import 'package:http/io_client.dart';

class OrderFormScreen extends StatefulWidget {
  @override
  _OrderFormScreenState createState() => _OrderFormScreenState();
}

class _OrderFormScreenState extends State<OrderFormScreen> {
  String? selectedGroup;
  String? selectedParty;
  String? selectedQuality;
  String? selectedStyle;
  int quantity = 0;
  final TextEditingController _partycontroller=TextEditingController();
  final TextEditingController _groupcontroller=TextEditingController();
  final TextEditingController _itemcontroller=TextEditingController();
  final TextEditingController _stylecontroller=TextEditingController();
  final List<String> party = [];
  final List<String> groups = [];
  final List<String> item = [];
  final List<String> style = [];
  final List<String> sized = [];
  // final Map<String, List<String>> qualities = {
  //   'Inner Wear-Mens': ['Super', 'Standard'],
  //   'Outer Wear-Womens': ['Premium', 'Economy'],
  //   'Accessories': ['High Quality', 'Basic Quality']
  // };
  // final Map<String, List<String>> styles = {
  //   'Super': ['RN-White', 'RN-Colour'],
  //   'Standard': ['Plain', 'Printed'],
  // };
  // final Map<String, List<String>> sizes = {
  //   'RN-White': ['S', 'M', 'L', 'XL', 'XXL'],
  //   'RN-Colour': ['75', '80', '85', '90', '95', '100', '105']
  // };

  late Database db;

  String apiUrl_all = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_partymaster&strFilter=%27%27';
  String apiUrl_agewise = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_partymaster&strFilter=%27%27';
  String apiUrl_group = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_groupmaster&strFilter=%27%27';
  String apiUrl_agent = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_agentmaster&strFilter=%27%27';
  String apiUrl_brand = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_brandmaster&strFilter=%27%27';
  String apiUrl_style = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_itemstyle&strFilter=%27%27';
  String apiUrl_item = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_itemname&strFilter=%27%27';
  String apiUrl_size = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_itemsize&strFilter=%27%27';



  Future<void> fetchPartyData() async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);


    final response = await ioClient.get(Uri.parse(apiUrl_all));

    if (response.statusCode == 200) {
      List<dynamic> jsonData = json.decode(response.body);

      setState(() {
        party.addAll(jsonData
            .where((party) => party['isactive'] == 1)
            .map((party) => party['partyname'] as String));
      });

      // Append active party names to the party list


    }

  }

  Future<void> fetchGroupData() async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);


    final response = await ioClient.get(Uri.parse(apiUrl_group));


    if(response.statusCode == 200){
      List<dynamic> jsonData = json.decode(response.body);
      setState(() {
        groups.addAll(jsonData.where((groups) => groups['isactive'] == 1).map((groups)=> groups['groupname'] as String));
      });
    }
  }

  Future<void> fetchItemData() async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);


    final response = await ioClient.get(Uri.parse(apiUrl_item));


    if(response.statusCode == 200){
      List<dynamic> jsonData = json.decode(response.body);
      setState(() {
        item.addAll(jsonData.map((item)=> item['itemname'] as String));
      });
    }
  }

  Future<void> fetchStyleData() async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);


    final response = await ioClient.get(Uri.parse(apiUrl_style));


    if(response.statusCode == 200){
      List<dynamic> jsonData = json.decode(response.body);
      setState(() {
        style.addAll(jsonData.map((style)=> style['stylename'] as String));
      });
    }
  }

  Future<void> fetchSizeData() async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);


    final response = await ioClient.get(Uri.parse(apiUrl_size));


    if(response.statusCode == 200){
      List<dynamic> jsonData = json.decode(response.body);
      setState(() {
        sized.addAll(jsonData.map((sized)=> sized['sizename'] as String));
      });
    }
  }


  @override
  void initState() {
    super.initState();
    initDatabase();
    fetchPartyData();
    fetchGroupData();
    fetchItemData();
    fetchStyleData();
    fetchSizeData();
  }

  Future<void> initDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'orders.db');

    db = await openDatabase(
      path,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE Orders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          group_name TEXT,
          quality TEXT,
          style TEXT,
          size TEXT,
          rate REAL,
          qty INTEGER
        )
        ''');
      },
      version: 1,
    );
  }

  Future<void> saveOrder(String group, String quality, String style, String size, double rate, int qty) async {
    await db.insert('Orders', {
      'group_name': group,
      'quality': quality,
      'style': style,
      'size': size,
      'rate': rate,
      'qty': qty,
    });

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Order Form'),
            GestureDetector(
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => CartScreen()),
                  );

                },
                child: Icon(Icons.shopping_cart))
          ],
        ),

      ),
      body: party.length >=1 ? Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // DropdownButtonFormField<String>(
            //   hint: Text('Select Party'),
            //   value: selectedParty,
            //   items: party.map((String group) {
            //     return DropdownMenuItem<String>(
            //       value: group,
            //       child: Text(group),
            //     );
            //   }).toList(),
            //   onChanged: (value) {
            //     setState(() {
            //       selectedParty = value;
            //     });
            //   },
            // ),
            Column(
              children: [
                FlutterDropdownSearch(
                  textController: _partycontroller,
                  items: party,
                  dropdownHeight: 280,
                  hintText: 'Party',
                )
              ],
            ),
            // DropdownButtonFormField<String>(
            //   hint: Text('Select Group',style: TextStyle(fontSize: 12),),
            //   value: selectedGroup,
            //   items: groups.map((String group) {
            //     return DropdownMenuItem<String>(
            //       value: group,
            //       child: Text(group),
            //     );
            //   }).toList(),
            //   onChanged: (value) {
            //     setState(() {
            //       selectedGroup = value;
            //       selectedQuality = null;
            //       selectedStyle = null;
            //     });
            //   },
            // ),
            FlutterDropdownSearch(
              textController: _groupcontroller,
              items: groups,
              dropdownHeight: 280,
              hintText: 'Group',
                // onChanged: (value) {
                //   setState(() {
                //     selectedGroup = value;
                //     selectedQuality = null;
                //     selectedStyle = null;
                //   });
                // }
            ),
            // if (_groupcontroller.text != '')
              // DropdownButtonFormField<String>(
              //   hint: Text('Select Item'),
              //   value: selectedQuality,
              //   items: qualities[selectedGroup!]!.map((String quality) {
              //     return DropdownMenuItem<String>(
              //       value: quality,
              //       child: Text(quality),
              //     );
              //   }).toList(),
              //   onChanged: (value) {
              //     setState(() {
              //       selectedQuality = value;
              //       selectedStyle = null;
              //     });
              //   },
              // ),
              FlutterDropdownSearch(
                textController: _itemcontroller,
                items: item,
                dropdownHeight: 280,
                hintText: 'Item',
              ),
            // if (_itemcontroller.text != '')
              // DropdownButtonFormField<String>(
              //   hint: Text('Select Style'),
              //   value: selectedStyle,
              //   items: styles[selectedQuality!]!.map((String style) {
              //     return DropdownMenuItem<String>(
              //       value: style,
              //       child: Text(style),
              //     );
              //   }).toList(),
              //   onChanged: (value) {
              //     setState(() {
              //       selectedStyle = value;
              //     });
              //   },
              // ),
              FlutterDropdownSearch(
                textController: _stylecontroller,
                items: style,
                dropdownHeight: 280,
                hintText: 'Style',
              ),
            // if (_stylecontroller.text!='')
              Text('Avaliable Size',style: TextStyle(fontSize: 23,fontWeight: FontWeight.bold,),),
              // Expanded(
              //   child: ListView.builder(
              //     itemCount: sizes[selectedStyle!]!.length,
              //     itemBuilder: (context, index) {
              //       String size = sizes[selectedStyle!]![index];
              //       return Row(
              //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              //         children: [
              //           Container(
              //               width:130,child: Text(size,style: TextStyle(fontSize: 25),)),
              //           Container(
              //             width:35,
              //             child: GestureDetector(
              //               child:Text('-',style: TextStyle(fontSize: 35),),
              //               onTap: () {
              //                 saveOrder(selectedGroup!, selectedQuality!, selectedStyle!, size, 75.0, 1); // Dummy data
              //                 ScaffoldMessenger.of(context).showSnackBar(
              //                   SnackBar(content: Text('Added $size to cart')),
              //                 );
              //               },
              //             ),
              //           ),
              //           Padding(
              //             padding: const EdgeInsets.all(8.0),
              //             child: Center(
              //               child: Container(
              //                 width:65,
              //                 height:40,
              //                 child: Center(
              //                   child: TextField(
              //                     // controller: qtyController,
              //                     keyboardType: TextInputType.number,
              //                     decoration: InputDecoration(
              //                       hintText: 'Qty', // Add 'Qty' label
              //                       border: OutlineInputBorder(), // Adds the box border
              //                     ),
              //                   ),
              //                 ),
              //
              //               ),
              //             ),
              //           ),
              //
              //           IconButton(
              //             icon: Icon(Icons.add),
              //             onPressed: () {
              //               saveOrder(selectedGroup!, selectedQuality!, selectedStyle!, size, 75.0, 1); // Dummy data
              //               ScaffoldMessenger.of(context).showSnackBar(
              //                 SnackBar(content: Text('Added $size to cart')),
              //               );
              //             },
              //           ),
              //         ],
              //       );
              //     },
              //   ),
              // ),
            // if (_stylecontroller.text != null)
            // SizeOrderWidget(
            //   sizes: sizes,
            //   selectedStyle: selectedStyle?? '',
            //   selectedGroup: selectedGroup?? '',
            //   selectedQuality: selectedQuality?? '',
            //   saveOrder: saveOrder, // Mock saveOrder
            // ),
      Expanded(
      child: ListView.builder(
      itemCount: sized.length,
      itemBuilder: (context, index) {
      String size = sized[index];
      /*
      itemCount: sizes[selectedStyle]!.length,
      itemBuilder: (context, index) {
      String size = sizes[selectedStyle]![index];*/

      // If controller for this size doesn't exist, create it
      if (!qtyControllers.containsKey(size)) {
      qtyControllers[size] = TextEditingController(text: '0'); // Default quantity is 1
      }

      return

      //   Row(
      // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      // children: [
      // Container(
      // width: 130,
      // child: Text(
      // size,
      // style: TextStyle(fontSize: 25),
      // ),
      // ),
      // // Minus Button
      // Container(
      // width: 35,
      // child: GestureDetector(
      // child: Text(
      // '-',
      // style: TextStyle(fontSize: 35),
      // ),
      // onTap: () {
      // int currentQty = int.parse(qtyControllers[size]!.text);
      // if (currentQty > 1) {
      // setState(() {
      // qtyControllers[size]!.text = (currentQty - 1).toString();
      // });
      // }
      // },
      // ),
      // ),
      // // Quantity Text Field
      // Padding(
      // padding: const EdgeInsets.all(8.0),
      // child: Center(
      // child: Container(
      // width: 65,
      // height: 40,
      // child: Center(
      // child: TextField(
      // controller: qtyControllers[size],
      // keyboardType: TextInputType.number,
      // textAlign: TextAlign.center,
      // decoration: InputDecoration(
      // hintText: 'Qty',
      // border: OutlineInputBorder(),
      // ),
      // ),
      // ),
      // ),
      // ),
      // ),
      // // Plus Button
      // IconButton(
      // icon: Icon(Icons.add),
      // onPressed: () {
      // int currentQty = int.parse(qtyControllers[size]!.text);
      // setState(() {
      // qtyControllers[size]!.text = (currentQty + 1).toString();
      // });
      // },
      // ),
      // ],
      // )
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // Size Text
            Container(
              width: 80,
              child: Text(
                size,
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            // Minus Button
            GestureDetector(
              onTap: () {
                int currentQty = int.parse(qtyControllers[size]!.text);
                if (currentQty > 1) {
                  setState(() {
                    qtyControllers[size]!.text = (currentQty - 1).toString();
                  });
                }
              },
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Icon(
                  Icons.remove,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
            // Quantity Text Field
            Container(
              width: 65,
              height: 40,
              child: TextField(
                controller: qtyControllers[size],
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'Qty',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey),
                  ),
                  contentPadding: EdgeInsets.symmetric(vertical: 8),
                ),
                style: TextStyle(fontSize: 16),
              ),
            ),
            // Plus Button
            GestureDetector(
              onTap: () {
                int currentQty = int.parse(qtyControllers[size]!.text);
                setState(() {
                  qtyControllers[size]!.text = (currentQty + 1).toString();
                });
              },
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Icon(
                  Icons.add,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
          ],
        )

      ;
      },
      ),
      ),
            if (_stylecontroller.text != null)
              buildAddToCartButton(),

          ],
        ),
      ) : Center(child: CircularProgressIndicator()),
    );
  }


  // This map holds the quantities for each size
  Map<String, TextEditingController> qtyControllers = {};

  @override
  void dispose() {
    // Dispose all the controllers
    qtyControllers.forEach((key, controller) {
      controller.dispose();
    });
    super.dispose();
  }

  // Method to add the item to the cart
  Future<void> addToCart() async {
    for (var size in sized) {
      int qty = int.parse(qtyControllers[size]!.text);
      await saveOrder(
        _groupcontroller.text,
        _itemcontroller.text,
        _stylecontroller.text,
        size,
        75.0, // Dummy rate
        qty,
      );

    }
    qtyControllers.forEach((key, controller) {
      controller = TextEditingController(text: '0');
    });
  }

  // "Add to Cart" button
  Widget buildAddToCartButton() {
    return ElevatedButton(
      onPressed: addToCart,
      child: Text('Add to Cart'),
    );
  }
}


















class SizeOrderWidget extends StatefulWidget {
  final Map<String, List<String>> sizes;
  final String selectedStyle;
  final String selectedGroup;
  final String selectedQuality;
  final Future<void> Function(String group, String quality, String style, String size, double rate, int qty) saveOrder;

  SizeOrderWidget({
    required this.sizes,
    required this.selectedStyle,
    required this.selectedGroup,
    required this.selectedQuality,
    required this.saveOrder,
  });

  @override
  _SizeOrderWidgetState createState() => _SizeOrderWidgetState();
}

class _SizeOrderWidgetState extends State<SizeOrderWidget> {
  // This map holds the quantities for each size
  Map<String, TextEditingController> qtyControllers = {};

  @override
  void dispose() {
    // Dispose all the controllers
    qtyControllers.forEach((key, controller) {
      controller.dispose();
    });
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        itemCount: widget.sizes[widget.selectedStyle]!.length,
        itemBuilder: (context, index) {
          String size = widget.sizes[widget.selectedStyle]![index];

          // If controller for this size doesn't exist, create it
          if (!qtyControllers.containsKey(size)) {
            qtyControllers[size] = TextEditingController(text: '1'); // Default quantity is 1
          }

          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 130,
                child: Text(
                  size,
                  style: TextStyle(fontSize: 25),
                ),
              ),
              // Minus Button
              Container(
                width: 35,
                child: GestureDetector(
                  child: Text(
                    '-',
                    style: TextStyle(fontSize: 35),
                  ),
                  onTap: () {
                    int currentQty = int.parse(qtyControllers[size]!.text);
                    if (currentQty > 1) {
                      setState(() {
                        qtyControllers[size]!.text = (currentQty - 1).toString();
                      });
                    }
                  },
                ),
              ),
              // Quantity Text Field
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(
                  child: Container(
                    width: 65,
                    height: 40,
                    child: Center(
                      child: TextField(
                        controller: qtyControllers[size],
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        decoration: InputDecoration(
                          hintText: 'Qty',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Plus Button
              IconButton(
                icon: Icon(Icons.add),
                onPressed: () {
                  int currentQty = int.parse(qtyControllers[size]!.text);
                  setState(() {
                    qtyControllers[size]!.text = (currentQty + 1).toString();
                  });
                },
              ),
            ],
          );
        },
      ),
    );
  }

  // Method to add the item to the cart
  Future<void> addToCart() async {
    for (var size in widget.sizes[widget.selectedStyle]!) {
      int qty = int.parse(qtyControllers[size]!.text);
      await widget.saveOrder(
        widget.selectedGroup,
        widget.selectedQuality,
        widget.selectedStyle.toString(),
        size,
        75.0, // Dummy rate
        qty,
      );

    }
  }

  // "Add to Cart" button
  Widget buildAddToCartButton() {
    return ElevatedButton(
      onPressed: addToCart,
      child: Text('Add to Cart'),
    );
  }
}






/*
class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late Database db;
  List<Map<String, dynamic>> orders = [];

  @override
  void initState() {
    super.initState();
    initDatabase();
  }

  Future<void> initDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'orders.db');

    db = await openDatabase(
      path,
      version: 1,
    );
    fetchOrders();
  }

  Future<void> fetchOrders() async {
    final List<Map<String, dynamic>> result = await db.rawQuery(
        'SELECT group_name, quality, style, size, rate, SUM(qty) as qty '
            'FROM Orders GROUP BY group_name, quality, style, size, rate'
    );

    setState(() {
      orders = result;
    });
  }

  Future<void> updateOrderQuantity(String style, String size, int newQty) async {
    await db.rawUpdate(
      'UPDATE Orders SET qty = ? WHERE style = ? AND size = ?',
      [newQty, style, size],
    );
    fetchOrders(); // Refresh the cart after the update
  }

  Future<void> deleteOrder(String group_name,String quality,String style,String size) async {
    await db.delete('Orders', where: 'group_name = ?and quality = ? and style = ? and size =?', whereArgs: [group_name,quality,style,size]);
    fetchOrders(); // Refresh the cart after deletion
  }


  Future<void> showEditQuantityDialog(String style, String size, int currentQty) async {
    TextEditingController qtyController = TextEditingController(text: currentQty.toString());

    await showDialog(
      context: this.context,  // Ensure 'context' here is the one from the widget's state
      builder: (BuildContext dialogContext) {  // Proper BuildContext type
        return AlertDialog(
          title: Text('Edit Quantity'),
          content: TextField(
            controller: qtyController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Enter new quantity'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(); // Close dialog without saving
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                int newQty = int.tryParse(qtyController.text) ?? currentQty;
                updateOrderQuantity(style, size, newQty);
                Navigator.of(dialogContext).pop(); // Close dialog after saving
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
      ),
      body: orders.isEmpty
          ? Center(child: Text('No items in cart'))
          : ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) {
          final order = orders[index];
          return ListTile(
            title: Text(
              '${order['group_name']} - ${order['style']} (${order['size']})',
            ),
            subtitle: Text(
              'Quality: ${order['quality']} | Rate: ${order['rate']}',
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: () {
                    showEditQuantityDialog(
                      order['style'],
                      order['size'],
                      order['qty'],
                    );
                  },
                  child: Text(
                    'Qty: ${order['qty']}',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    deleteOrder(order['group_name'],order['quality'],order['style'],order['size']);
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
*/


class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late Database db;
  List<Map<String, dynamic>> orders = [];

  @override
  void initState() {
    super.initState();
    initDatabase();
  }

  Future<void> initDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'orders.db');

    db = await openDatabase(
      path,
      version: 1,
    );
    fetchOrders();
  }

  Future<void> fetchOrders() async {
    final List<Map<String, dynamic>> result = await db.rawQuery(
        'SELECT group_name, quality, style, size, rate, SUM(qty) as qty '
            'FROM Orders GROUP BY group_name, quality, style, size, rate'
    );

    // Organize data by group_name, quality, and style into a matrix-like format for size columns
    Map<String, Map<String, dynamic>> groupedOrders = {};

    for (var order in result) {
      String key = "${order['group_name']}_${order['quality']}_${order['style']}";
      if (!groupedOrders.containsKey(key)) {
        groupedOrders[key] = {
          'group_name': order['group_name'],
          'quality': order['quality'],
          'style': order['style'],
          'rate': order['rate'],
          'sizes': {
            'S': 0,
            'M': 0,
            'L': 0,
            'XL': 0,
            'XXL': 0,
            '3XL': 0,
            '4XL': 0,
            '5XL': 0,
          },
          'sizes1': {

            '70': 0,
            '75': 0,
            '80': 0,
            '85': 0,
            '90': 0,
            '95': 0,
            '100': 0,
            '105': 0,
          },'sizes2': {

            '45': 0,
            '50': 0,
            '55': 0,
            '60': 0,
            '65': 0,
            '70': 0,
            '75': 0,
            '80': 0,
          },
          'totalQty': 0,
          'totalAmount': 0.0
        };
      }

      // Update the sizes matrix
      groupedOrders[key]?['sizes'][order['size']] = order['qty'];
      groupedOrders[key]?['sizes1'][order['size']] = order['qty'];
      groupedOrders[key]?['sizes2'][order['size']] = order['qty'];

      // Update total quantities and amounts
      groupedOrders[key]?['totalQty'] += order['qty'];
      groupedOrders[key]?['totalAmount'] += order['qty'] * order['rate'];
    }

    setState(() {
      orders = groupedOrders.values.toList();
    });
  }

  Future<void> updateOrderQuantity(String style, String size, int newQty) async {
    await db.rawUpdate(
      'UPDATE Orders SET qty = ? WHERE style = ? AND size = ?',
      [newQty, style, size],
    );
    fetchOrders(); // Refresh the cart after the update
  }

  Future<void> deleteOrder(String group_name, String quality, String style, String size) async {
    await db.delete('Orders', where: 'group_name = ? and quality = ? and style = ? and size =?', whereArgs: [group_name, quality, style, size]);
    fetchOrders(); // Refresh the cart after deletion
  }

  Future<void> showEditQuantityDialog(String style, String size, int currentQty) async {
    TextEditingController qtyController = TextEditingController(text: currentQty.toString());

    await showDialog(
      context: this.context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('Edit Quantity'),
          content: TextField(
            controller: qtyController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Enter new quantity'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(); // Close dialog without saving
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                int newQty = int.tryParse(qtyController.text) ?? currentQty;
                updateOrderQuantity(style, size, newQty);
                Navigator.of(dialogContext).pop(); // Close dialog after saving
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // Define the sizes as columns
    List<String> sizes = ['S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL', '5XL'];
    List<String> sizes1= ['70', '75', '80', '85', '90', '95', '100', '105'];
    List<String> sizes2= ['45', '50', '60', '65', '70', '75', '80', '85'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Cart Items'),
      ),
      body: orders.isEmpty
          ? Center(child: Text('No items in cart'))
          : SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Table Header
              Table(
                border: TableBorder.all(),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                columnWidths: {
                  0: FixedColumnWidth(150), // Quality/Style
                  // 1: FixedColumnWidth(150), // Group Name
                  // Dynamic widths for size columns
                  for (int i = 0; i < sizes.length; i++) i + 1: FixedColumnWidth(60),
                  sizes.length + 1: FixedColumnWidth(80), // Total Qty
                  sizes.length + 2: FixedColumnWidth(100), // Total Amount
                },
                children: [
                  TableRow(
                    decoration: BoxDecoration(color: Colors.redAccent),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Group Name\nStyle & Quality', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child:
                      // ),
                      for (var size in sizes)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(size, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                        ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Total Qty', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Total Amount', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                    ],
                  ),
                ],
              ),
              // Table Data
              Table(
                border: TableBorder.all(),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                columnWidths: {
                  0: FixedColumnWidth(150),
                  // 1: FixedColumnWidth(150),
                  for (int i = 0; i < sizes.length; i++) i + 1: FixedColumnWidth(60),
                  sizes.length + 1: FixedColumnWidth(80),
                  sizes.length + 2: FixedColumnWidth(100),
                },
                children: orders.map((order) {
                  return TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Text("${order['group_name']}\n${order['style']} - ${order['quality']}"),

                          ],
                        ),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child:
                      // ),
                      // Render quantities for each size
                      for (var size in sizes)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: GestureDetector(
                            onTap: () {
                              showEditQuantityDialog(order['style'], size, order['sizes'][size]);
                            },
                            child: Text(
                              '${order['sizes'][size]}',
                              style: TextStyle(color: order['sizes'][size] > 0 ? Colors.blue : Colors.black),
                            ),
                          ),
                        ),
                      // Total quantity
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(order['totalQty'].toString()),
                      ),
                      // Total amount
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Rs. ${order['totalAmount'].toStringAsFixed(2)}'),
                      ),
                    ],
                  );
                }).toList(),
              ),
              Divider(),

              // Table Header
              Table(
                border: TableBorder.all(),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                columnWidths: {
                  0: FixedColumnWidth(150), // Quality/Style
                  // 1: FixedColumnWidth(150), // Group Name
                  // Dynamic widths for size columns
                  for (int i = 0; i < sizes1.length; i++) i + 1: FixedColumnWidth(60),
                  sizes1.length + 1: FixedColumnWidth(80), // Total Qty
                  sizes1.length + 2: FixedColumnWidth(100), // Total Amount
                },
                children: [
                  TableRow(
                    decoration: BoxDecoration(color: Colors.redAccent),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Group Name\nStyle & Quality', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child:
                      // ),
                      for (var size in sizes1)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(size, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                        ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Total Qty', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Total Amount', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                    ],
                  ),
                ],
              ),
              // Table Data
              Table(
                border: TableBorder.all(),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                columnWidths: {
                  0: FixedColumnWidth(150),
                  // 1: FixedColumnWidth(150),
                  for (int i = 0; i < sizes1.length; i++) i + 1: FixedColumnWidth(60),
                  sizes1.length + 1: FixedColumnWidth(80),
                  sizes1.length + 2: FixedColumnWidth(100),
                },
                children: orders.map((order) {
                  return TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Text("${order['group_name']}\n${order['style']} - ${order['quality']}"),

                          ],
                        ),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child:
                      // ),
                      // Render quantities for each size
                      for (var size in sizes1)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: GestureDetector(
                            onTap: () {
                              showEditQuantityDialog(order['style'], size, order['sizes1'][size]);
                            },
                            child: Text(
                              '${order['sizes1'][size]}',
                              style: TextStyle(color: order['sizes1'][size] > 0 ? Colors.blue : Colors.black),
                            ),
                          ),
                        ),
                      // Total quantity
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(order['totalQty'].toString()),
                      ),
                      // Total amount
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Rs. ${order['totalAmount'].toStringAsFixed(2)}'),
                      ),
                    ],
                  );
                }).toList(),
              ),
              Divider(),

        /*      // Table Header
              Table(
                border: TableBorder.all(),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                columnWidths: {
                  0: FixedColumnWidth(150), // Quality/Style
                  // 1: FixedColumnWidth(150), // Group Name
                  // Dynamic widths for size columns
                  for (int i = 0; i < sizes2.length; i++) i + 1: FixedColumnWidth(60),
                  sizes2.length + 1: FixedColumnWidth(80), // Total Qty
                  sizes2.length + 2: FixedColumnWidth(100), // Total Amount
                },
                children: [
                  TableRow(
                    decoration: BoxDecoration(color: Colors.redAccent),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Group Name\nStyle & Quality', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child:
                      // ),
                      for (var size in sizes2)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(size, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                        ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Total Qty', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Total Amount', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                      ),
                    ],
                  ),
                ],
              ),
              // Table Data
              Table(
                border: TableBorder.all(),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                columnWidths: {
                  0: FixedColumnWidth(150),
                  // 1: FixedColumnWidth(150),
                  for (int i = 0; i < sizes2.length; i++) i + 1: FixedColumnWidth(60),
                  sizes2.length + 1: FixedColumnWidth(80),
                  sizes2.length + 2: FixedColumnWidth(100),
                },
                children: orders.map((order) {
                  return TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            Text("${order['group_name']}\n${order['style']} - ${order['quality']}"),

                          ],
                        ),
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.all(8.0),
                      //   child:
                      // ),
                      // Render quantities for each size
                      for (var size in sizes2)
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: GestureDetector(
                            onTap: () {
                              showEditQuantityDialog(order['style'], size, order['sizes2'][size]);
                            },
                            child: Text(
                              '${order['sizes2'][size]}',
                              style: TextStyle(color: order['sizes2'][size] ?? 0> 0 ? Colors.blue : Colors.black),
                            ),
                          ),
                        ),
                      // Total quantity
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(order['totalQty'].toString()),
                      ),
                      // Total amount
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Rs. ${order['totalAmount'].toStringAsFixed(2)}'),
                      ),
                    ],
                  );
                }).toList(),
              ),*/
            ],
          ),
        ),
      ),
    );
  }
}

/*
class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  late Database db;
  List<Map<String, dynamic>> orders = [];

  @override
  void initState() {
    super.initState();
    initDatabase();
  }

  Future<void> initDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'orders.db');

    db = await openDatabase(
      path,
      version: 1,
    );
    fetchOrders();
  }

  Future<void> fetchOrders() async {
    final List<Map<String, dynamic>> result = await db.rawQuery('select group_name,quality,style,size,rate,sum(qty) as qty from Orders group by group_name,quality,style,size,rate');

    setState(() {
      orders = result;
    });
  }

  Future<void> deleteOrder(String style) async {
    await db.delete('Orders', where: 'style = ?', whereArgs: [style]);
    fetchOrders(); // Refresh the cart after deletion
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
      ),
      body: orders.isEmpty
          ? Center(child: Text('No items in cart'))
          : ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) {
          final order = orders[index];
          return ListTile(
            title: Text(
              '${order['group_name']} - ${order['style']} (${order['size']})',
            ),
            subtitle: Text(
              'Quality: ${order['quality']} | Qty: ${order['qty']} | Rate: ${order['rate']}',
            ),
            trailing: IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                deleteOrder(order['style']);
              },
            ),
          );
        },
      ),
    );
  }
}
*/
