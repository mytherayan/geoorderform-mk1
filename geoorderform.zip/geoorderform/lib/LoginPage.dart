
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:snow_login/utils/animations.dart';

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geoorderform/main.dart';
import 'package:http/io_client.dart';
String UniversalAgentName  = '';

class ShowUpAnimation extends StatefulWidget {
  /// GETTING THE CHILD WIDGET
  final Widget child;
  /// GETTING THE ANIMATION DURATION
  int? delay;

  ShowUpAnimation({required this.child,  this.delay});

  @override
  _ShowUpAnimationState createState() => _ShowUpAnimationState();
}

class _ShowUpAnimationState extends State<ShowUpAnimation> with TickerProviderStateMixin {
  /// CREATING THE ANIMATION CONTROLLER VARIABLE
  late AnimationController _animController;
  /// CREATING THE ANIMATION  VARIABLE OF TYPE OFFSET
  late Animation<Offset> _animOffset;
  /// CREATING THE TIMER VARIABLE
  late Timer _timer;

  @override
  void initState() {
    super.initState();

    _animController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    final curve =
    CurvedAnimation(curve: Curves.decelerate, parent: _animController);
    _animOffset =
        Tween<Offset>(begin: const Offset(0.0, 0.35), end: Offset.zero)
            .animate(curve);


    if (widget.delay == null) {
      _animController.forward();
    } else {
      _timer= Timer(Duration(milliseconds: widget.delay!), () {
        _animController.forward();
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    _animController.dispose();
    _timer.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animController,
      child: SlideTransition(
        position: _animOffset,
        child: widget.child,
      ),
    );
  }
}

// import '../data/bg_data.dart';

/// List of Background Images////
List<String>bgList=[
  "assets/bg1.jpeg",
];
// import '../utils/text_utils.dart';


class TextUtil extends StatelessWidget {
  String text;
  Color? color;
  double? size;
  bool? weight;
  TextUtil({super.key,required this.text,this.size,this.color,this.weight});

  @override
  Widget build(BuildContext context) {
    return  Text(text,

      style: TextStyle(color:color??Colors.white,fontSize:size?? 16,
          fontWeight:weight==null?FontWeight.w600: FontWeight.w700
      ),);
  }
}

//login screen
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  int selectedIndex=0;
  bool showOption=false;

  final TextEditingController agentIdController = TextEditingController();
  final TextEditingController agentNumController = TextEditingController();
  final List<Map<String, dynamic>> agentList = []; // Change to store agent info correctly

  Future<void> validateAgent(BuildContext context) async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);

    String apiUrl = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_agentmaster&strFilter=%27%27';

    final response = await ioClient.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      List<dynamic> jsonData = json.decode(response.body);
      setState(() {
        // Filter and add agents while ensuring the correct type
        agentList.addAll(
          jsonData
              .where((agent) => agent['isactive'] == 1)
              .map((agent) => agent as Map<String, dynamic>)
              .toList(),
        );
      });

      String inputAgentId = agentIdController.text;
      String inputAgentNum = agentNumController.text;
print(agentIdController.text);
print(agentNumController.text);
      // Find the agent by ID and mobile number
      Map<String, dynamic>? foundAgent = agentList.firstWhere(
            (agent) => agent['agentid'].toString() == inputAgentId &&
            agent['agentwhatsappno'] == inputAgentNum,
        orElse: () => {}, // This will return null if no match is found
      );

      if (foundAgent != null) {
        // String agentName =
        setState(() {
          UniversalAgentName = foundAgent['agentname'];
        });
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => Dashboard(),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Agent not found or inactive.')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load agents.')),
      );
    }
  }


/*  final TextEditingController agentid=TextEditingController();
  final TextEditingController agentnum=TextEditingController();
  final List<String> agentlist = [];

  Future<void> validateAgent()async {
    HttpClient client = HttpClient();
    client.badCertificateCallback =
    ((X509Certificate cert, String host, int port) => true);
    IOClient ioClient = IOClient(client);


    String apiUrl_agewise = 'http://genapi.suninfotechnologies.in/GEO/GetData?caption=get_agentmaster&strFilter=%27%27';

    final response_group = await ioClient.get(Uri.parse(apiUrl_agewise));

    if(response_group.statusCode == 200){
      List<dynamic> jsonData = json.decode(response_group.body);
      setState(() {
        agentlist.addAll(jsonData.where((agentlist) => agentlist['isactive'] == 1).map((agentlist)=> agentlist['agentid'] as String));
      });
    }
  }*/


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // floatingActionButton: Container(
      //   margin:const  EdgeInsets.symmetric(vertical: 10),
      //   height: 49,
      //   width: double.infinity,
      //
      //   child: Row(
      //     children: [
      //       Expanded(
      //           child:showOption? ShowUpAnimation(
      //             delay: 100,
      //             child: ListView.builder(
      //                 shrinkWrap: true,
      //                 itemCount: bgList.length,
      //                 scrollDirection: Axis.horizontal,
      //                 itemBuilder: (context,index){
      //                   return   GestureDetector(
      //                     onTap: (){
      //                       setState(() {
      //                         selectedIndex=index;
      //                       });
      //                     },
      //                     child: CircleAvatar(
      //                       radius: 30,
      //
      //                       backgroundColor:selectedIndex==index? Colors.white:Colors.transparent,
      //                       child: Padding(
      //                         padding:const  EdgeInsets.all(1),
      //                         child: CircleAvatar(
      //                           radius: 30,
      //                           backgroundImage: AssetImage(bgList[index],),
      //                         ),
      //                       ),
      //                     ),
      //                   );
      //
      //                 }),
      //           ):const SizedBox()),
      //       const  SizedBox(width: 20,),
      //       showOption? GestureDetector(
      //           onTap: (){
      //             setState(() {
      //               showOption=false;
      //             });
      //           },
      //           child:const  Icon(Icons.close,color: Colors.white,size: 30,)) :
      //       GestureDetector(
      //         onTap: (){
      //           setState(() {
      //             showOption=true;
      //           });
      //         },
      //         child: CircleAvatar(
      //
      //           backgroundColor: Colors.white,
      //           child: Padding(
      //             padding:const  EdgeInsets.all(1),
      //             child: CircleAvatar(
      //               radius: 30,
      //               backgroundImage: AssetImage(bgList[selectedIndex],),
      //             ),
      //           ),
      //         ),
      //       )
      //     ],
      //   ),
      // ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration:  BoxDecoration(
          image: DecorationImage(
              image: AssetImage(bgList[0]),fit: BoxFit.fill
          ),

        ),
        alignment: Alignment.center,
        child: Container(
          height: 400,
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 30),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.white),
            borderRadius: BorderRadius.circular(15),
            color: Colors.black.withOpacity(0.1),


          ),
          child: ClipRRect(

            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(filter:ImageFilter.blur(sigmaY: 5,sigmaX: 5),
                child:Padding(
                  padding: const EdgeInsets.all(25),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const   Spacer(),
                      Center(child: TextUtil(text: "Login",weight: true,size: 30,)),
                      const   Spacer(),

                      // TextUtil(text: "Agent ID",),
                      Container(
                        height: 35,
                        decoration:const  BoxDecoration(
                            border: Border(bottom: BorderSide(color: Colors.white))
                        ),
                        child:TextFormField(
                          style: const TextStyle(color: Colors.white),
                          controller: agentIdController,
                          decoration:const  InputDecoration(
                            hintText: 'Agent ID',
                           hintStyle: TextStyle(color: Colors.white),
                           prefixIcon: Icon(Icons.person_2,color: Colors.white,),
                            fillColor: Colors.white,
                            border: InputBorder.none,),
                        ),
                      ),
                      const   Spacer(),
                      // TextUtil(text: "Mobile No",),
                      Container(
                        height: 35,
                        decoration:const  BoxDecoration(
                            border: Border(bottom: BorderSide(color: Colors.white))
                        ),
                        child:TextFormField(
                          style: const TextStyle(color: Colors.white),
                          controller: agentNumController,
                          decoration:const  InputDecoration(
                            hintText: 'Mobile No',
                            hintStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(Icons.phone,color: Colors.white,),
                            fillColor: Colors.white,
                            border: InputBorder.none,),
                        ),
                      ),
                      const   Spacer(),
                      const   Spacer(),
                      GestureDetector(
                        onTap: (){
                          validateAgent(context);
                          // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Dashboard()));
                        },
                        child: Container(
                          height: 40,
                          width: double.infinity,
                          decoration:  BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(30)
                          ),
                          alignment: Alignment.center,
                          child: TextUtil(text: "Log In",color: Colors.black,),
                        ),
                      ),
                      const   Spacer(),
                      // Center(child: TextUtil(text: "Don't have a account REGISTER",size: 12,weight: true,)),
                      const   Spacer(),


                    ],
                  ),
                ) ),
          ),
        ),


      ),



    );
  }
}
